package com.chp.project.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.chp.cokeapicommon.model.entity.User;


/**
 * @Entity com.chp.project.model.domain.User
 */
public interface UserMapper extends BaseMapper<User> {

}




