package com.chp.project.common;

import lombok.Data;

import java.io.Serializable;

/**
 * id 请求
 *
 * @author chp
 */
@Data
public class IdRequest implements Serializable {
    /**
     * id
     */
    private Long id;

    private static final long serialVersionUID = 1L;
}