package com.chp.cokeapiinterface;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CokeApiInterfaceApplication {

    public static void main(String[] args) {
        SpringApplication.run(CokeApiInterfaceApplication.class, args);
    }

}
